# PlateShare - Leftover Food Sharing App (hackathon MVP)

Restaurants, hotels, event organisers and households list surplus food. NGOs and volunteers claim it and collect it.
Every listing has a pickup deadline and a donor-stated safe-time window, and the impact dashboard only counts food that was recorded as collected.

## Run it
1. Install Node.js 16 or newer
2. `npm start` (or `node server.js`), then open http://localhost:3000
3. `npm run check` runs syntax checks and 13 API tests (no `npm install` needed, zero dependencies)

## 2-minute judge demo
1. Open the app. Three **DEMO**-tagged listings are already there (available, claimed, collected).
2. **Donate food** tab → "Act as demo restaurant" → fill the form (try submitting it empty to see validation) → Post.
3. **NGO / Receiver** tab → "Act as demo NGO" → Claim your new listing (pick a pickup time). Donor phone appears only now.
4. Press **Mark as collected**. Watch "meals rescued" go up by exactly that listing's servings.
5. **All donations** tab → search and filter by status. "Reset demo data" restores the samples and keeps listings you created.

## Status workflow
Available → Claimed → Collected. Also: Claimed → Available (receiver releases), Available → Withdrawn (donor), Available → Expired (automatic once the pickup deadline or safe window passes).
All other transitions are rejected by the server (HTTP 409), and the UI always shows the stored status.

## Impact rules (no fake numbers)
All numbers are computed from stored listings. 1 serving = 1 meal. Only COLLECTED listings count as rescued. Blank weight is estimated at 0.35 kg per serving and marked "estimated".

## Safety and privacy
- PlateShare never certifies food as safe. Cards show the donor's stated window, donor handling notes and general guidance for the category, plus a reminder to inspect at pickup.
- Phone numbers are only returned to the donor of a listing and to the receiver who claimed it.
- Demo limitation: there is no login. That privacy is a name match, not real authentication. Real accounts are the first thing to add.

## Storage and limitations
Data lives in `data/db.json` on the machine running the server. Everyone using that server sees the same data, and it survives refreshes and restarts. It is not a cloud database: run one shared server for a multi-device demo. Demo records carry `demo: true`; reset only replaces those.

## API
GET `/api/listings` · POST `/api/listings` · POST `/api/listings/:id/claim|collect|release|cancel` · POST `/api/demo/reset`

## Files
`server.js` (API, validation, storage) · `public/` (index.html, app.js, style.css) · `test/api.test.js`
