// Zero-dependency API test. Run: npm test   (starts the server on a temp port with a temp database)
const { spawn } = require('child_process'), http = require('http'), assert = require('assert'), os = require('os'), path = require('path'), fs = require('fs');
const PORT = 3900 + Math.floor(Math.random() * 90), DB = path.join(os.tmpdir(), 'plateshare-test-' + Date.now() + '.json');
const call = (method, url, data) => new Promise((ok, bad) => {
  const body = data ? JSON.stringify(data) : null;
  const r = http.request({ port: PORT, path: url, method, headers: { 'Content-Type': 'application/json' } }, res => {
    let s = ''; res.on('data', c => (s += c)); res.on('end', () => { let j; try { j = JSON.parse(s); } catch { j = s; } ok({ code: res.statusCode, body: j }); });
  }); r.on('error', bad); if (body) r.write(body); r.end();
});
const H = 3600 * 1000, iso = ms => new Date(Date.now() + ms).toISOString();
const good = () => ({ donor: 'Test Cafe', donorType: 'Restaurant', title: 'Soup', category: 'Cooked meal', servings: '10', shelfHours: '4', preparedAt: iso(0), pickupBy: iso(2 * H), location: '1 Test Rd', contact: '+91 90000 11111', clientId: 'c-' + Math.random() });
let passed = 0; const t = async (name, fn) => { await fn(); passed++; console.log('  ok  ' + name); };

(async () => {
  const srv = spawn('node', ['server.js'], { env: { ...process.env, PORT, DB_PATH: DB }, cwd: path.join(__dirname, '..'), stdio: 'ignore' });
  try {
    for (let i = 0; i < 30; i++) { try { await call('GET', '/api/listings'); break; } catch { await new Promise(r => setTimeout(r, 100)); } }
    let id;
    await t('seeds 3 demo listings: available, claimed, collected', async () => {
      const { body } = await call('GET', '/api/listings'); const s = body.listings.map(l => l.status).sort();
      assert.deepStrictEqual(s, ['available', 'claimed', 'collected']); assert(body.listings.every(l => l.demo));
      assert.strictEqual(body.stats.mealsRescued, 60); // only the collected demo listing counts
    });
    await t('rejects invalid donations (negative servings, past deadline, no contact, deadline outside safe window)', async () => {
      for (const bad of [{ servings: '-5' }, { servings: '0' }, { pickupBy: iso(-H) }, { contact: '' }, { title: '' }, { shelfHours: '1', pickupBy: iso(3 * H) }, { donorType: 'Alien' }]) {
        const r = await call('POST', '/api/listings', { ...good(), ...bad }); assert.strictEqual(r.code, 400, JSON.stringify(bad));
      }
    });
    await t('creates a donation and shows it in listings', async () => {
      const r = await call('POST', '/api/listings', good()); assert.strictEqual(r.code, 201); id = r.body.id;
      const l = (await call('GET', '/api/listings')).body.listings.find(x => x.id === id); assert.strictEqual(l.status, 'available');
    });
    await t('double submit with the same clientId creates one record', async () => {
      const d = good(); const a = await call('POST', '/api/listings', d), b = await call('POST', '/api/listings', d);
      assert.strictEqual(a.body.id, b.body.id);
      assert.strictEqual((await call('GET', '/api/listings')).body.listings.filter(l => l.clientId === d.clientId).length, 0); // clientId never leaks
    });
    await t('phone numbers are hidden from the public', async () => {
      const l = (await call('GET', '/api/listings')).body.listings.find(x => x.id === id); assert.strictEqual(l.contact, undefined);
      const own = (await call('GET', '/api/listings?viewerDonor=Test%20Cafe')).body.listings.find(x => x.id === id); assert.strictEqual(own.contact, '+91 90000 11111');
    });
    await t('cannot collect or release an available listing (invalid transitions)', async () => {
      assert.strictEqual((await call('POST', `/api/listings/${id}/collect`)).code, 409);
      assert.strictEqual((await call('POST', `/api/listings/${id}/release`)).code, 409);
    });
    await t('claim validates name and pickup time', async () => {
      assert.strictEqual((await call('POST', `/api/listings/${id}/claim`, { pickupTime: iso(H) })).code, 400);
      assert.strictEqual((await call('POST', `/api/listings/${id}/claim`, { name: 'A', pickupTime: iso(5 * H) })).code, 400);
    });
    await t('5 simultaneous claims: exactly one wins', async () => {
      const rs = await Promise.all([1, 2, 3, 4, 5].map(i => call('POST', `/api/listings/${id}/claim`, { name: 'R' + i, pickupTime: iso(H) })));
      assert.deepStrictEqual(rs.map(r => r.code).sort(), [200, 409, 409, 409, 409]);
    });
    await t('claimed details are stored; receiver sees donor phone, public does not', async () => {
      const winner = (await call('GET', '/api/listings')).body.listings.find(x => x.id === id).claimedBy;
      assert.strictEqual((await call('GET', '/api/listings')).body.listings.find(x => x.id === id).contact, undefined);
      assert.strictEqual((await call('GET', '/api/listings?viewerName=' + winner)).body.listings.find(x => x.id === id).contact, '+91 90000 11111');
    });
    await t('release returns food to available, then it can be re-claimed', async () => {
      assert.strictEqual((await call('POST', `/api/listings/${id}/release`)).body.status, 'available');
      assert.strictEqual((await call('POST', `/api/listings/${id}/claim`, { name: 'Final', pickupTime: iso(H) })).code, 200);
    });
    await t('collect → collected; meals rescued increases by the servings; cannot withdraw afterwards', async () => {
      const before = (await call('GET', '/api/listings')).body.stats.mealsRescued;
      assert.strictEqual((await call('POST', `/api/listings/${id}/collect`)).body.status, 'collected');
      assert.strictEqual((await call('GET', '/api/listings')).body.stats.mealsRescued, before + 10);
      assert.strictEqual((await call('POST', `/api/listings/${id}/cancel`)).code, 409);
      assert.strictEqual((await call('POST', `/api/listings/${id}/claim`, { name: 'Late', pickupTime: iso(H) })).code, 409);
    });
    await t('demo reset replaces only demo data and keeps real listings', async () => {
      await call('POST', '/api/listings/demo-available/claim', { name: 'X', pickupTime: iso(H) });
      const r = await call('POST', '/api/demo/reset'); assert.strictEqual(r.body.removedDemo, 3); assert(r.body.keptReal >= 2);
      const ls = (await call('GET', '/api/listings')).body.listings;
      assert.strictEqual(ls.find(x => x.id === 'demo-available').status, 'available'); assert(ls.find(x => x.id === id));
    });
    await t('unknown routes and bad JSON return clean errors; path traversal blocked', async () => {
      assert.strictEqual((await call('POST', '/api/listings/nope/claim', { name: 'a' })).code, 404);
      assert.strictEqual((await call('GET', '/..%2fserver.js')).code, 404);
      assert.strictEqual((await call('GET', '/')).code, 200);
    });
    console.log(`\n${passed} tests passed`);
  } catch (e) { console.error('\nFAILED:', e.message); process.exitCode = 1; }
  finally { srv.kill(); [DB, DB + '.tmp'].forEach(f => fs.existsSync(f) && fs.unlinkSync(f)); }
})();
