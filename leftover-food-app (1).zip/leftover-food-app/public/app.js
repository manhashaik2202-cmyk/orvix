const $ = s => document.querySelector(s);
const H = 3600 * 1000;
let state = null;            // null until first successful load
let role = localStorage.getItem('ps_role') || 'donor';
let me = JSON.parse(localStorage.getItem('ps_me') || '{"donor":"","name":"","org":"","phone":""}');
let claimId = null, clientId = null, toastTimer;

const DEMO_DONOR = 'Demo Spice Garden Restaurant', DEMO_NGO = { name: 'Demo Volunteer', org: 'Demo Helping Hands NGO', phone: '+91 90000 00002' };
const HANDLING = {
  'Cooked meal': 'Keep hot (above 60°C) or cold (below 5°C). Reheat until steaming hot. Discard if unsure.',
  'Bakery': 'Keep dry and covered. Discard if mouldy or damp.',
  'Fruits and vegetables': 'Keep cool. Wash before eating. Discard anything bruised or rotting.',
  'Packaged': 'Check the seal and the printed expiry date.',
  'Other': 'Check the condition of the food when you collect it.'
};

const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const fmt = t => new Date(t).toLocaleString([], { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' });
const localInput = t => new Date(t - new Date().getTimezoneOffset() * 60000).toISOString().slice(0, 16);
const toIso = v => { const d = new Date(v); return v && !isNaN(d) ? d.toISOString() : ''; }; // send real instants, not timezone-less strings
const left = ms => { if (ms <= 0) return 'expired'; const m = Math.round(ms / 60000); return m >= 60 ? `${Math.floor(m / 60)}h ${m % 60}m left` : `${m}m left`; };
const newId = () => (crypto.randomUUID ? crypto.randomUUID() : Date.now() + '-' + Math.random().toString(36).slice(2));
const same = (a, b) => !!a && !!b && a.trim().toLowerCase() === b.trim().toLowerCase();
const saveMe = () => localStorage.setItem('ps_me', JSON.stringify(me));

function toast(msg) { const t = $('#toast'); t.textContent = msg; t.classList.add('show'); clearTimeout(toastTimer); toastTimer = setTimeout(() => t.classList.remove('show'), 3200); }
async function api(url, method = 'GET', data) {
  // Only the identity of the side you are currently on is sent, so switching roles never leaks the other side's data.
  const q = new URLSearchParams({ viewerName: role === 'taker' ? me.name || '' : '', viewerDonor: role === 'donor' ? me.donor || '' : '' });
  let r;
  try { r = await fetch(url + (url.includes('?') ? '&' : '?') + q, { method, headers: { 'Content-Type': 'application/json' }, body: data ? JSON.stringify(data) : undefined }); }
  catch { throw new Error('Cannot reach the server. Check that it is running.'); }
  let j = {}; try { j = await r.json(); } catch {}
  if (!r.ok) { const e = new Error(j.error || 'Something went wrong. Please try again.'); e.errors = j.errors; throw e; }
  return j;
}
async function busy(btn, fn) { if (btn) { btn.disabled = true; btn.dataset.t = btn.textContent; btn.textContent = 'Please wait…'; } try { return await fn(); } finally { if (btn && btn.isConnected) { btn.disabled = false; btn.textContent = btn.dataset.t; } } }

async function refresh() {
  try { state = await api('/api/listings'); $('#netErr').hidden = true; }
  catch (e) {
    if (!state) { $('#list').innerHTML = `<div class="empty err-box"><p>${esc(e.message)}</p><button id="retry">Try again</button></div>`; $('#retry').onclick = refresh; $('#listTitle').textContent = 'Donations'; return; }
    $('#netErr').textContent = 'Connection problem: showing the last data we received. ' + e.message; $('#netErr').hidden = false; return;
  }
  render();
}

// Donor-stated window only. PlateShare never certifies food as safe.
function windowInfo(l) {
  const now = Date.now(), total = l.expiresAt - l.preparedAt, rem = l.expiresAt - now, pct = Math.max(0, Math.min(100, (rem / total) * 100));
  if (rem <= 0) return { cls: 'bad', label: 'Past donor\u2019s time window', pct: 0, rem };
  if (pct < 35 || rem < 1.5 * H) return { cls: 'soon', label: 'Window ending soon', pct, rem };
  return { cls: 'fresh', label: 'Within donor\u2019s time window', pct, rem };
}

function card(l, mode) {
  const f = windowInfo(l), mine = same(me.donor, l.donor), myClaim = same(me.name, l.claimedBy);
  const cls = l.status === 'collected' ? 'done' : l.status === 'expired' ? 'expired' : l.status === 'cancelled' ? 'cancelled' : l.status === 'claimed' ? 'claimedc' : f.cls;
  const badge = { available: f.label, claimed: 'Claimed', collected: 'Collected', expired: 'Expired', cancelled: 'Withdrawn' }[l.status];
  let actions = '';
  if (mode === 'taker' && l.status === 'available') actions = `<button data-claim="${l.id}">Claim this food</button>`;
  if (mode === 'taker' && l.status === 'claimed' && myClaim) actions = `<button data-collect="${l.id}">Mark as collected</button><button class="ghost" data-release="${l.id}">Release back to pool</button>`;
  if (mode === 'donor' && mine && l.status === 'available') actions = `<button class="ghost" data-cancel="${l.id}">Withdraw listing</button>`;
  if (mode === 'donor' && mine && l.status === 'claimed') actions = `<button data-collect="${l.id}">Confirm handed over</button>`;
  const claim = l.claimedBy ? `<p class="note"><b>${l.status === 'collected' ? 'Collected by' : 'Claimed by'}</b> ${esc(l.claimedBy)}${l.claimOrg ? ' (' + esc(l.claimOrg) + ')' : ''} · pickup ${fmt(l.pickupTime)}${l.claimPhone ? ' · ' + esc(l.claimPhone) : ''}${l.collectedAt ? ' · collected ' + fmt(l.collectedAt) : ''}</p>` : '';
  const contact = l.contact ? `<span>Donor phone: ${esc(l.contact)}</span>` : (l.hasContact && l.status === 'available' ? '<span>Donor phone shown after you claim</span>' : '');
  const stale = l.status === 'claimed' && f.rem <= 0 ? '<p class="warn">The donor\u2019s time window has passed. Do not distribute this food unless you are sure it is safe.</p>' : '';
  return `<article class="item ${cls}">
    <div class="head"><div><h3>${esc(l.title)} ${l.demo ? '<span class="tag">DEMO</span>' : ''}</h3><div class="by">${esc(l.donor)}${l.donorType ? ' (' + esc(l.donorType) + ')' : ''} · ${esc(l.category)}</div></div><span class="badge">${badge}</span></div>
    ${l.status === 'available' ? `<div class="meter" title="Time left in the donor's stated window"><i style="width:${f.pct}%"></i></div><div class="facts"><span><b>${left(f.rem)}</b> in the donor's stated window</span></div>` : ''}
    <div class="facts" style="margin-top:6px"><span><b>${l.servings}</b> servings (~${l.kg} kg${l.kgEstimated ? ', estimated' : ''})</span><span>Pickup by <b>${fmt(l.pickupBy)}</b></span><span>${esc(l.location)}</span>${contact}</div>
    <div class="facts"><span>Prepared ${fmt(l.preparedAt)}</span><span>Donor says safe for ${l.shelfHours}h</span></div>
    ${l.notes ? `<p class="note">${esc(l.notes)}</p>` : ''}${claim}${stale}
    <details><summary>Food handling and safety</summary>
      ${l.handling ? `<p><b>Donor's note:</b> ${esc(l.handling)}</p>` : ''}
      <p><b>General guidance:</b> ${esc(HANDLING[l.category] || HANDLING.Other)}</p>
      <p class="muted">Listed food is not inspected or certified by PlateShare. Check it yourself at pickup.</p></details>
    ${actions ? `<div class="actions">${actions}</div>` : ''}</article>`;
}

function renderStats() {
  const s = state.stats;
  $('#stats').innerHTML = [[s.totalListed, 'donations listed'], [s.available, 'available now'], [s.claimedTotal, 'claimed (' + s.awaitingPickup + ' awaiting pickup)'], [s.mealsRescued, 'meals rescued (collected)'], [s.kgRescued, 'kg rescued']]
    .map(([n, t]) => `<div class="stat"><b>${n}</b><span>${esc(t)}</span></div>`).join('');
  $('#rule').textContent = s.rule + (s.demoListings ? ` Includes ${s.demoListings} demo listing(s).` : '');
}

function renderSide() {
  const side = $('#side');
  if (role === 'donor') {
    clientId = newId(); // one id per rendered form: resubmitting the same form can never create a second record
    const now = Date.now(), cats = (state?.categories || ['Cooked meal', 'Bakery', 'Fruits and vegetables', 'Packaged', 'Other']), types = state?.donorTypes || ['Restaurant', 'Hotel', 'Event organizer', 'Household'];
    side.innerHTML = `<form id="postForm" novalidate><h2>Share surplus food</h2>
      <ul class="formerr" id="formErr" role="alert" hidden></ul>
      <div class="two"><label>Your name or organisation<input name="donor" value="${esc(me.donor)}" autocomplete="organization"></label>
      <label>I am a<select name="donorType">${types.map(t => `<option>${esc(t)}</option>`).join('')}</select></label></div>
      <label>Food name<input name="title" placeholder="e.g. Veg fried rice"></label>
      <div class="two"><label>Category<select name="category">${cats.map(t => `<option>${esc(t)}</option>`).join('')}</select></label>
      <label>Quantity (servings)<input name="servings" type="number" min="1" step="1" inputmode="numeric"></label></div>
      <div class="two"><label>Weight in kg (optional)<input name="kg" type="number" step="0.1" min="0"></label>
      <label>Safe for (hours)<input name="shelfHours" type="number" step="0.5" min="0.5" value="4"></label></div>
      <label>Prepared at<input name="preparedAt" type="datetime-local" value="${localInput(now)}"></label>
      <label>Pickup deadline<input name="pickupBy" type="datetime-local" value="${localInput(now + 3 * H)}"></label>
      <label>Pickup address<input name="location" autocomplete="street-address"></label>
      <label>Contact phone (only shown to the receiver who claims it)<input name="contact" type="tel" autocomplete="tel"></label>
      <label>Handling / storage note (optional)<input name="handling" placeholder="e.g. Keep covered, reheat before serving"></label>
      <label>Notes (veg, allergens, containers)<textarea name="notes" rows="2"></textarea></label>
      <button class="primary">Post food</button></form>`;
    $('#postForm').onsubmit = submitPost;
  } else if (role === 'taker') {
    side.innerHTML = `<div class="panel"><h2>How to collect</h2><p>1. Claim food that is still within its time window and choose a pickup time.<br>2. Collect it, check it yourself, then press <b>Mark as collected</b>.<br>3. Changed your mind? Release it so others can claim it.</p>${me.name ? `<p class="muted">Acting as <b>${esc(me.name)}</b>. Your claimed food is listed below.</p>` : '<p class="muted">Your name is saved when you make your first claim.</p>'}</div>`;
  } else {
    side.innerHTML = `<div class="panel"><h2>All donations</h2><p>Every listing and its current status. Use the filters to narrow it down. Switch to <b>NGO / Receiver</b> to claim food.</p></div>`;
  }
}

async function submitPost(e) {
  e.preventDefault();
  const f = e.target, d = Object.fromEntries(new FormData(f));
  const errs = [], n = Number(d.servings), sh = Number(d.shelfHours), prep = new Date(d.preparedAt), pick = new Date(d.pickupBy);
  if (!d.donor.trim()) errs.push('Enter your name or organisation.');
  if (!d.title.trim()) errs.push('Enter the food name.');
  if (!Number.isInteger(n) || n < 1) errs.push('Servings must be a whole number of 1 or more.');
  if (d.kg !== '' && !(Number(d.kg) > 0)) errs.push('Weight must be above 0, or leave it blank.');
  if (!(sh >= 0.5)) errs.push('"Safe for" must be at least 0.5 hours.');
  if (isNaN(prep)) errs.push('Enter the preparation time.'); else if (prep > Date.now() + 300000) errs.push('Preparation time cannot be in the future.');
  if (isNaN(pick)) errs.push('Enter a pickup deadline.'); else if (pick <= Date.now()) errs.push('Pickup deadline must be in the future.');
  else if (!isNaN(prep) && sh > 0 && pick > prep.getTime() + sh * H) errs.push('Pickup deadline must be inside the "safe for" window.');
  if (!d.location.trim()) errs.push('Enter the pickup address.');
  if (d.contact.replace(/\D/g, '').length < 7) errs.push('Enter a contact phone number.');
  showErrs(errs); if (errs.length) return;
  try {
    await busy(f.querySelector('.primary'), () => api('/api/listings', 'POST', { ...d, preparedAt: toIso(d.preparedAt), pickupBy: toIso(d.pickupBy), clientId }));
    me.donor = d.donor.trim(); saveMe();
    toast('Posted! Your food is now listed for NGOs and volunteers.');
    await refresh(); renderSide();
  } catch (er) { showErrs(er.errors || [er.message]); }
}
function showErrs(errs) { const u = $('#formErr'); if (!u) return; u.hidden = !errs.length; u.innerHTML = errs.map(x => `<li>${esc(x)}</li>`).join(''); if (errs.length) u.scrollIntoView({ block: 'nearest' }); }

// Poll refreshes stats and the list only; it never rebuilds the form, so typing is not lost.
function render() {
  $('#roleDonor').classList.toggle('on', role === 'donor');
  $('#roleTaker').classList.toggle('on', role === 'taker');
  $('#roleAll').classList.toggle('on', role === 'all');
  const c = $('#cat'); if (c.options.length === 1) state.categories.forEach(x => c.add(new Option(x, x)));
  $('#stat').hidden = role === 'taker'; // receivers only ever see what they can act on
  renderStats(); renderList();
}
function renderList() {
  if (!state) return;
  const q = $('#q').value.toLowerCase(), cat = $('#cat').value, st = $('#stat').value;
  let items = state.listings.filter(l => (!cat || l.category === cat) && (!st || role === 'taker' || l.status === st) && (!q || (l.title + ' ' + l.location + ' ' + l.donor).toLowerCase().includes(q)));
  if (role === 'donor') { $('#listTitle').textContent = 'Your listings'; items = items.filter(l => me.donor && same(me.donor, l.donor)); }
  else if (role === 'taker') { $('#listTitle').textContent = 'Available food and your claims'; items = items.filter(l => l.status === 'available' || (l.status === 'claimed' && same(me.name, l.claimedBy))); }
  else $('#listTitle').textContent = 'All donations';
  const rank = { available: 0, claimed: 1, collected: 2, expired: 3, cancelled: 4 };
  items.sort((a, b) => rank[a.status] - rank[b.status] || (a.status === 'available' ? a.expiresAt - b.expiresAt : b.createdAt - a.createdAt));
  const filtering = q || cat || st;
  const empty = filtering ? 'No donations match your search or filters.'
    : role === 'donor' ? 'You have not posted any food yet. Fill in the form, or press "Act as demo restaurant" above.'
    : role === 'taker' ? 'No food is available right now. Check back soon.' : 'No donations have been listed yet.';
  $('#list').innerHTML = items.length ? items.map(l => card(l, role)).join('') : `<div class="empty">${empty}</div>`;
}

function setRole(r) { role = r; localStorage.setItem('ps_role', r); if (state) render(); renderSide(); refresh(); }
$('#roleDonor').onclick = () => setRole('donor');
$('#roleTaker').onclick = () => setRole('taker');
$('#roleAll').onclick = () => setRole('all');
$('#q').oninput = $('#cat').onchange = $('#stat').onchange = renderList;

$('#actDonor').onclick = () => { me.donor = DEMO_DONOR; saveMe(); setRole('donor'); toast('Acting as the demo restaurant.'); };
$('#actNgo').onclick = () => { me = { ...me, ...DEMO_NGO }; saveMe(); setRole('taker'); toast('Acting as the demo NGO.'); };
$('#resetDemo').onclick = async e => {
  if (!confirm('Reset demo data? Only the DEMO-tagged sample listings are replaced. Listings you created are kept.')) return;
  try { const r = await busy(e.target, () => api('/api/demo/reset', 'POST')); await refresh(); toast(`Demo data reset. ${r.keptReal} of your own listing(s) kept.`); } catch (er) { toast(er.message); }
};

$('#list').onclick = async e => {
  const b = e.target.closest('button'); if (!b || b.id === 'retry') return;
  const act = (k, url, msg) => busy(b, async () => { await api(`/api/listings/${b.dataset[k]}/${url}`, 'POST'); toast(msg); await refresh(); });
  try {
    if (b.dataset.claim) {
      claimId = b.dataset.claim; const l = state.listings.find(x => x.id === claimId), f = $('#claimForm');
      $('#claimInfo').textContent = `${l.title} from ${l.donor}, pickup by ${fmt(l.pickupBy)}`;
      f.name.value = me.name; f.org.value = me.org; f.phone.value = me.phone;
      f.pickupTime.value = localInput(Math.min(Date.now() + H, l.pickupBy)); f.pickupTime.max = localInput(l.pickupBy);
      $('#claimErr').textContent = ''; $('#claimDlg').showModal();
    } else if (b.dataset.collect) await act('collect', 'collect', 'Recorded as collected. Thank you!');
    else if (b.dataset.release) await act('release', 'release', 'Released. Others can now claim it.');
    else if (b.dataset.cancel) await act('cancel', 'cancel', 'Listing withdrawn.');
  } catch (er) { toast(er.message); refresh(); }
};

$('#claimForm').onsubmit = async e => {
  if (e.submitter && e.submitter.value === 'cancel') return;
  e.preventDefault();
  const f = e.target, d = Object.fromEntries(new FormData(f)), err = $('#claimErr');
  if (!d.name.trim()) { err.textContent = 'Enter your name.'; return; }
  if (!d.pickupTime || isNaN(new Date(d.pickupTime))) { err.textContent = 'Choose a pickup time.'; return; }
  try {
    await busy($('#claimGo'), () => api(`/api/listings/${claimId}/claim`, 'POST', { ...d, pickupTime: toIso(d.pickupTime) }));
    me = { ...me, name: d.name.trim(), org: d.org, phone: d.phone }; saveMe(); $('#claimDlg').close();
    toast('Claimed! Donor contact details are now shown on the listing.'); await refresh();
  } catch (er) { err.textContent = er.message; refresh(); }
};

$('#list').innerHTML = '<div class="skeleton"></div><div class="skeleton"></div><div class="skeleton"></div>';
$('#listTitle').textContent = 'Loading donations…';
renderSide(); refresh(); setInterval(refresh, 30000); // keeps countdowns and availability live
