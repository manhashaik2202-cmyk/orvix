// PlateShare - Leftover Food Sharing App - zero-dependency Node.js server (Node 16+)
const http = require('http'), fs = require('fs'), path = require('path');
const PORT = process.env.PORT || 3000;
const DB = process.env.DB_PATH || path.join(__dirname, 'data', 'db.json');
const PUB = path.join(__dirname, 'public');
const H = 3600 * 1000;
const MAX_BODY = 50 * 1024;
const KG_PER_SERVING = 0.35; // used only when the donor leaves weight blank
const CATEGORIES = ['Cooked meal', 'Bakery', 'Fruits and vegetables', 'Packaged', 'Other'];
const DONOR_TYPES = ['Restaurant', 'Hotel', 'Event organizer', 'Household'];

// ---------- demo data (all fictional, flagged demo:true so reset never touches real records) ----------
function demoSeed(now = Date.now()) {
  const base = { donor: 'Demo Spice Garden Restaurant', donorType: 'Restaurant', contact: '+91 90000 00001', location: '12 Demo Street, Sample Town', demo: true, createdAt: now, clientId: null };
  return [
    { ...base, id: 'demo-available', title: 'Veg biryani and raita', category: 'Cooked meal', servings: 40, kg: 14,
      notes: 'Contains dairy (raita). Packed in food-grade containers.', handling: 'Keep covered and hot. Eat within 4 hours.',
      preparedAt: now - 1 * H, shelfHours: 6, expiresAt: now + 5 * H, pickupBy: now + 4 * H, status: 'available', createdAt: now },
    { ...base, id: 'demo-claimed', title: 'Dal tadka and jeera rice', category: 'Cooked meal', servings: 25, kg: 9,
      notes: 'Vegan. Bring your own large containers.', handling: 'Reheat until steaming hot before serving.',
      preparedAt: now - 2 * H, shelfHours: 6, expiresAt: now + 4 * H, pickupBy: now + 2 * H, status: 'claimed',
      claimedBy: 'Demo Volunteer', claimOrg: 'Demo Helping Hands NGO', claimPhone: '+91 90000 00002', pickupTime: now + 1 * H, createdAt: now - 1 * H },
    { ...base, id: 'demo-collected', title: 'Bread rolls and buns', category: 'Bakery', servings: 60, kg: 12,
      notes: 'Baked this morning.', handling: 'Store dry and covered.',
      preparedAt: now - 6 * H, shelfHours: 24, expiresAt: now + 18 * H, pickupBy: now - 1 * H, status: 'collected',
      claimedBy: 'Demo Volunteer', claimOrg: 'Demo Helping Hands NGO', claimPhone: '+91 90000 00002', pickupTime: now - 2 * H, collectedAt: now - 1.5 * H, createdAt: now - 5 * H }
  ];
}

// ---------- storage ----------
function writeDb(d) {
  fs.mkdirSync(path.dirname(DB), { recursive: true });
  const tmp = DB + '.tmp';
  fs.writeFileSync(tmp, JSON.stringify(d, null, 2));
  fs.renameSync(tmp, DB); // atomic replace: a crash mid-write cannot corrupt the db
}
function load() {
  if (!fs.existsSync(DB)) { const s = demoSeed(); writeDb(s); return s; }
  let d;
  try { d = JSON.parse(fs.readFileSync(DB, 'utf8')); if (!Array.isArray(d)) throw new Error('not an array'); }
  catch (e) { // never silently destroy data: keep the unreadable file, start fresh
    const bak = DB + '.corrupt-' + Date.now();
    fs.renameSync(DB, bak); console.warn('db.json was unreadable; moved to ' + bak);
    const s = demoSeed(); writeDb(s); return s;
  }
  // migrate listings from the first version of this app: its built-in samples were ids seed0-2
  let changed = false;
  d.forEach(l => { if (/^seed\d$/.test(l.id) && !l.demo) { l.demo = true; changed = true; } });
  if (changed) writeDb(d);
  return d;
}

// A listing nobody collected in time becomes expired so it can never be claimed.
function expire(list) {
  const now = Date.now(); let changed = false;
  list.forEach(l => { if (l.status === 'available' && now > Math.min(l.expiresAt, l.pickupBy)) { l.status = 'expired'; changed = true; } });
  return changed;
}

// Meals rescued = servings in COLLECTED listings only. Listed or claimed food is not counted as rescued.
function stats(list) {
  const done = list.filter(l => l.status === 'collected'), n = s => list.filter(l => l.status === s).length;
  return {
    totalListed: list.length, available: n('available'), awaitingPickup: n('claimed'), collected: done.length,
    claimedTotal: n('claimed') + n('collected'), expired: n('expired'), withdrawn: n('cancelled'),
    mealsRescued: done.reduce((a, l) => a + l.servings, 0), kgRescued: +done.reduce((a, l) => a + l.kg, 0).toFixed(1),
    demoListings: list.filter(l => l.demo).length,
    rule: '1 serving = 1 meal. Only COLLECTED listings count. If a donor leaves weight blank, weight is estimated at ' + KG_PER_SERVING + ' kg per serving.'
  };
}

// Privacy: phone numbers are only returned to the donor of a listing or the receiver who claimed it.
// NOTE: there is no login in this MVP, so this is a name match, not real authentication.
const same = (a, b) => !!a && !!b && String(a).trim().toLowerCase() === String(b).trim().toLowerCase();
function view(l, viewer) {
  const { clientId, ...o } = l;
  const isDonor = same(viewer.donor, l.donor), isReceiver = same(viewer.name, l.claimedBy);
  o.hasContact = !!l.contact;
  if (!(isDonor || (isReceiver && (l.status === 'claimed' || l.status === 'collected')))) delete o.contact;
  if (!(isDonor || isReceiver)) delete o.claimPhone;
  return o;
}

// ---------- validation ----------
const clean = (v, n = 200) => String(v == null ? '' : v).trim().slice(0, n);
const time = v => { const t = new Date(v).getTime(); return Number.isFinite(t) ? t : NaN; };
function validateListing(b, now) {
  const e = [];
  const donor = clean(b.donor), title = clean(b.title), location = clean(b.location), contact = clean(b.contact, 40);
  if (!donor) e.push('Enter your name or organisation.');
  if (!DONOR_TYPES.includes(b.donorType)) e.push('Choose who you are (restaurant, hotel, event organiser or household).');
  if (!title) e.push('Enter the food name.');
  if (!CATEGORIES.includes(b.category)) e.push('Choose a food category.');
  const servings = Number(b.servings);
  if (!Number.isInteger(servings) || servings < 1 || servings > 5000) e.push('Servings must be a whole number from 1 to 5000.');
  let kg = b.kg === '' || b.kg == null ? NaN : Number(b.kg);
  if (!Number.isNaN(kg) && !(kg > 0 && kg <= 5000)) e.push('Weight must be above 0 and at most 5000 kg (or leave it blank).');
  const shelf = Number(b.shelfHours);
  if (!(shelf >= 0.5 && shelf <= 72)) e.push('"Safe for" must be between 0.5 and 72 hours.');
  const prepared = time(b.preparedAt), pickupBy = time(b.pickupBy);
  if (Number.isNaN(prepared)) e.push('Enter a valid preparation time.');
  else if (prepared > now + 5 * 60000) e.push('Preparation time cannot be in the future.');
  else if (prepared < now - 72 * H) e.push('Food prepared more than 72 hours ago cannot be listed.');
  if (Number.isNaN(pickupBy)) e.push('Enter a pickup deadline.');
  else if (pickupBy <= now) e.push('Pickup deadline must be in the future.');
  else if (!Number.isNaN(prepared) && shelf > 0 && pickupBy > prepared + shelf * H) e.push('Pickup deadline must fall inside the "safe for" window.');
  if (!location) e.push('Enter the pickup address.');
  if (contact.replace(/\D/g, '').length < 7) e.push('Enter a contact phone number (at least 7 digits).');
  if (e.length) return { errors: e };
  return { item: {
    donor, donorType: b.donorType, title, category: b.category, servings,
    kg: Number.isNaN(kg) ? +(servings * KG_PER_SERVING).toFixed(1) : kg, kgEstimated: Number.isNaN(kg),
    location, contact, notes: clean(b.notes, 300), handling: clean(b.handling, 200),
    preparedAt: prepared, shelfHours: shelf, expiresAt: prepared + shelf * H, pickupBy
  } };
}

// Allowed status transitions. Anything not listed here is rejected with 409.
const TRANSITIONS = {
  claim: { from: 'available', to: 'claimed', error: 'This food is no longer available.' },
  collect: { from: 'claimed', to: 'collected', error: 'Only claimed food can be marked collected.' },
  release: { from: 'claimed', to: 'available', error: 'Only claimed food can be released.' },
  cancel: { from: 'available', to: 'cancelled', error: 'Only available food can be withdrawn.' }
};

// ---------- http helpers ----------
const send = (res, code, obj) => { res.writeHead(code, { 'Content-Type': 'application/json' }); res.end(JSON.stringify(obj)); };
const body = req => new Promise((ok, bad) => {
  let b = '', size = 0;
  req.on('data', c => { size += c.length; if (size > MAX_BODY) { bad({ code: 413, msg: 'Request too large.' }); req.destroy(); } else b += c; });
  req.on('end', () => { try { ok(JSON.parse(b || '{}')); } catch { bad({ code: 400, msg: 'Invalid JSON.' }); } });
  req.on('error', () => bad({ code: 400, msg: 'Request failed.' }));
});
const MIME = { '.html': 'text/html; charset=utf-8', '.css': 'text/css', '.js': 'text/javascript', '.svg': 'image/svg+xml' };

async function handle(req, res) {
  const url = new URL(req.url, 'http://x'), p = url.pathname;

  if (p.startsWith('/api/')) {
    const viewer = { name: url.searchParams.get('viewerName'), donor: url.searchParams.get('viewerDonor') };
    // Body is read BEFORE the database is loaded, so load -> check -> save runs in one synchronous
    // step. Two simultaneous claims therefore cannot both succeed.
    const b = req.method === 'POST' ? await body(req) : {};
    const list = load(), now = Date.now();
    const changed = expire(list);

    if (req.method === 'GET' && p === '/api/listings') {
      if (changed) writeDb(list);
      return send(res, 200, { listings: list.map(l => view(l, viewer)).sort((a, z) => z.createdAt - a.createdAt), stats: stats(list), categories: CATEGORIES, donorTypes: DONOR_TYPES });
    }

    if (req.method === 'POST' && p === '/api/listings') {
      const dup = b.clientId && list.find(l => l.clientId === String(b.clientId)); // double-submit protection
      if (dup) return send(res, 200, view(dup, { donor: dup.donor }));
      const r = validateListing(b, now);
      if (r.errors) return send(res, 400, { error: r.errors[0], errors: r.errors });
      const item = { id: now.toString(36) + Math.random().toString(36).slice(2, 6), ...r.item, status: 'available', createdAt: now, clientId: b.clientId ? clean(b.clientId, 64) : null };
      list.push(item); writeDb(list);
      return send(res, 201, view(item, { donor: item.donor }));
    }

    if (req.method === 'POST' && p === '/api/demo/reset') {
      const kept = list.filter(l => !l.demo); // real (non-demo) listings are never touched
      const fresh = kept.concat(demoSeed(now)); writeDb(fresh);
      return send(res, 200, { ok: true, removedDemo: list.length - kept.length, keptReal: kept.length });
    }

    const m = p.match(/^\/api\/listings\/([\w-]+)\/(claim|collect|release|cancel)$/);
    if (req.method === 'POST' && m) {
      const item = list.find(l => l.id === m[1]);
      if (!item) return send(res, 404, { error: 'Listing not found.' });
      const t = TRANSITIONS[m[2]];
      if (item.status !== t.from) { if (changed) writeDb(list); return send(res, 409, { error: t.error }); }
      if (m[2] === 'claim') {
        const name = clean(b.name), pt = time(b.pickupTime);
        if (!name) return send(res, 400, { error: 'Enter your name.' });
        if (Number.isNaN(pt)) return send(res, 400, { error: 'Choose a pickup time.' });
        if (pt < now - 60000) return send(res, 400, { error: 'Pickup time cannot be in the past.' });
        if (pt > item.pickupBy) return send(res, 400, { error: 'Pickup time must be before the donor\'s deadline.' });
        Object.assign(item, { claimedBy: name, claimOrg: clean(b.org), claimPhone: clean(b.phone, 40), pickupTime: pt, claimedAt: now });
      } else if (m[2] === 'collect') {
        item.collectedAt = now;
      } else if (m[2] === 'release') {
        ['claimedBy', 'claimOrg', 'claimPhone', 'pickupTime', 'claimedAt'].forEach(k => delete item[k]);
      }
      item.status = t.to;
      expire(list); // a released listing that is already past its window becomes expired, not available
      writeDb(list);
      return send(res, 200, view(item, { donor: item.donor, name: item.claimedBy }));
    }
    return send(res, 404, { error: 'Not found' });
  }

  let rel; try { rel = decodeURIComponent(p); } catch { res.writeHead(400); return res.end('Bad request'); }
  const file = path.join(PUB, rel === '/' ? 'index.html' : rel);
  if (!file.startsWith(PUB + path.sep) || !fs.existsSync(file) || fs.statSync(file).isDirectory()) { res.writeHead(404); return res.end('Not found'); }
  res.writeHead(200, { 'Content-Type': MIME[path.extname(file)] || 'application/octet-stream', 'Cache-Control': 'no-cache' });
  fs.createReadStream(file).pipe(res);
}

http.createServer((req, res) => {
  handle(req, res).catch(err => {
    if (res.headersSent) return res.end();
    if (err && err.code && err.msg) return send(res, err.code, { error: err.msg });
    console.error(err); send(res, 500, { error: 'Server error. Please try again.' });
  });
}).listen(PORT, () => console.log(`PlateShare running at http://localhost:${PORT}`));
